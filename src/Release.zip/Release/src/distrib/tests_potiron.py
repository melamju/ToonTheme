from utils import *
	
Clean()

GitUpdate33()
PatchAll()
Build_VC11Express_64()
RunAll()
Build_VC14Express_64()
RunAll()
Build_CodeBlocks()
RunAll()

Clean()

GitUpdate21()
PatchAll()
Build_VC14Express_64()
RunAll()

Clean()
GitUpdate33()






